
ingat ges ini program tidak terdiri dari OPENAI API KEY jadi sebelum mengunkannya siapkan terlebih dahulu key nya

sipkan file .env dengan dan masukan keynya 

program streamlit ini membaca file pdf yang teletak pada folder "data" 


